public abstract class LibraryItem {
    private String title;
    private String author;
    private int itemId;
    private boolean isBorrowed;

    public LibraryItem(String title, String author, int itemId, boolean isBorrowed) {
        this.title = title;
        this.author = author;
        this.itemId = itemId;
        this.isBorrowed = isBorrowed;
    }

    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }

    public int getItemId() {
        return itemId;
    }

    public boolean isBorrowed() {
        return isBorrowed;
    }

    public void borrowItem() {
        if (!isBorrowed) {
            isBorrowed = true;
            System.out.println(title + " has been borrowed.");
        } else {
            System.out.println(title + " is already borrowed.");
        }
    }

    public void returnItem() {
        if (isBorrowed) {
            isBorrowed = false;
            System.out.println(title + " has been returned.");
        } else {
            System.out.println(title + " was not borrowed.");
        }
    }

    public abstract void displayInfo();

    public int getItemID() {
        return itemId;
    }
}
