import java.util.ArrayList;
import java.util.List;

public class Library {
    private List<LibraryItem> items;

    public Library() {
        items = new ArrayList<>();
    }

    public void addBook(Book book) {
        items.add(book);
        System.out.println("Added: " + book.getTitle());
    }

    public void displayBooks() {
        if (items.isEmpty()) {
            System.out.println("No books available.");
            return;
        }
        for (LibraryItem item : items) {
            item.displayInfo();
        }
    }

    public LibraryItem findBookById(int itemId) {
        for (LibraryItem item : items) {
            if (item.getItemId() == itemId) {
                return item;
            }
        }
        return null; // Not found
    }
}
