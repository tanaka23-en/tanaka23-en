public class Librarian extends User{

    public Librarian(String name,int userID){

        super(name,userID);
    }
    //a librarian can add and remove books

    public void addBook(LibraryItem item){
        System.out.println("Book titled: "+item.getTitle()+" has been successfully added");

    }
    public void removeBook(LibraryItem item){
        System.out.println("Book titled: "+item.getItemID()+" has been successfully removed");
    }
}
