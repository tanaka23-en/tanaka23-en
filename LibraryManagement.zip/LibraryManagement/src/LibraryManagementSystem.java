import java.util.Scanner;

public class LibraryManagementSystem {
    private Library library;
    private Scanner scanner;

    public LibraryManagementSystem() {
        library = new Library();
        scanner = new Scanner(System.in);
    }

    public void start() {
        while (true) {
            System.out.println("Welcome to the Library Management System");
            System.out.println("1. User Menu");
            System.out.println("2. Librarian Menu");
            System.out.println("3. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    userMenu();
                    break;
                case 2:
                    librarianMenu();
                    break;
                case 3:
                    System.out.println("Exiting...");
                    return;
                default:
                    System.out.println("Invalid option. Try again.");
            }
        }
    }

    private void userMenu() {
        while (true) {
            System.out.println("User Menu");
            System.out.println("1. Borrow a Book");
            System.out.println("2. Return a Book");
            System.out.println("3. View Available Books");
            System.out.println("4. Go Back");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    System.out.print("Enter Book ID to borrow: ");
                    int borrowId = scanner.nextInt();
                    LibraryItem borrowItem = library.findBookById(borrowId);
                    if (borrowItem != null) {
                        borrowItem.borrowItem();
                    } else {
                        System.out.println("Book not found.");
                    }
                    break;
                case 2:
                    System.out.print("Enter Book ID to return: ");
                    int returnId = scanner.nextInt();
                    LibraryItem returnItem = library.findBookById(returnId);
                    if (returnItem != null) {
                        returnItem.returnItem();
                    } else {
                        System.out.println("Book not found.");
                    }
                    break;
                case 3:
                    library.displayBooks();
                    break;
                case 4:
                    return; // Go back to the main menu
                default:
                    System.out.println("Invalid option. Try again.");
            }
        }
    }

    private void librarianMenu() {
        while (true) {
            System.out.println("Librarian Menu");
            System.out.println("1. Add a Book");
            System.out.println("2. View Available Books");
            System.out.println("3. Go Back");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    System.out.print("Enter Book Title: ");
                    String title = scanner.nextLine();
                    System.out.print("Enter Author: ");
                    String author = scanner.nextLine();
                    System.out.print("Enter Item ID: ");
                    int itemId = scanner.nextInt();
                    scanner.nextLine(); // Consume newline
                    System.out.print("Enter Genre: ");
                    String genre = scanner.nextLine();

                    Book newBook = new Book(title, author, itemId, genre);
                    library.addBook(newBook);
                    break;
                case 2:
                    library.displayBooks();
                    break;
                case 3:
                    return; // Go back to the main menu
                default:
                    System.out.println("Invalid option. Try again.");
            }
        }
    }

    public static void main(String[] args) {
        LibraryManagementSystem system = new LibraryManagementSystem();
        system.start();
    }
}
