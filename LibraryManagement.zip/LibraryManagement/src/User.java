public class User {
    private String name;
    private int userID;

    public User(String name,int userID){
        this.name=name;
        this.userID=userID;
    }

    public String getName(){
        return name;
    }
    public int getUserID(){
        return userID;
    }

    //user can borrow items
    public void borrowItem(LibraryItem item){

        item.borrowItem();
    }
    public void returnItem(LibraryItem item){

        item.returnItem();
    }
}
