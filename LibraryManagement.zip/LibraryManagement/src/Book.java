public class Book extends LibraryItem {
    private String genre;

    public Book(String title, String author, int itemId, String genre) {
        super(title, author, itemId, false);
        this.genre = genre;
    }

    public String getGenre() {
        return genre;
    }

    @Override
    public void displayInfo() {
        System.out.println("Book ID: " + getItemId() + ", Title: " + getTitle() +
                ", Author: " + getAuthor() + ", Genre: " + genre);
    }
}
