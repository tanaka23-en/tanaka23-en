interface ShipmentUpdator {
    void updateShipmentStatus(Shipment shipment, String status);
}
